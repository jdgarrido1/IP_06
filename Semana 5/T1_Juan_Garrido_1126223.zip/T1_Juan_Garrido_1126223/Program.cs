﻿class Program
{

    static void Main(string[] args)
    {
        Console.WriteLine("MI segundo Programa");
        string sNombre, sEdad, sCarrera, sCarne;

        Console.WriteLine("Ingrese nombre: ");
        sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese edad: ");
        sEdad = Console.ReadLine();
        Console.WriteLine("Ingrese carrera: ");
        sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese carne: ");
        sCarne = Console.ReadLine();

        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carnet: " + sCarne);

        Console.WriteLine("Soy " + sNombre + "tengo " + sEdad + "años y estudio la carrera de " + sCarrera + "Mi numero de carne es " + sCarne);
        Console.ReadKey();
    }
}
