﻿

class program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Ejercicio 1");

        int num1 = 0;
        Console.WriteLine("Numero ENTERO");
        num1 = Int32.Parse(Console.ReadLine());

        if (num1 > 0)
        {
            Console.WriteLine("El numero es positivo");
        }
        else if(num1 < 0)
        {
            Console.WriteLine("El numero es negativo");
        }
        else if (num1 == 0)
        {
            Console.WriteLine("El numero es igual a cero");
        }

        Console.ReadLine();
        Console.Clear();

        Console.WriteLine("Ejercicio 2");
        Console.WriteLine("Ingrese un numero de dia");
        string Semana;
        Semana = Console.ReadLine();
        switch (Semana)
        {
            case "1":
                Console.WriteLine("El dia es Lunes");
                break;
            case "2":
                Console.WriteLine("El dia ingreado es Martes");
                break;
            case "3":
                Console.WriteLine("El dia ingresado es Miercoles");
                break;
            case "4":
                Console.WriteLine("El dia ingresado es Jueves");
                break;
            case "5":
                Console.WriteLine("El dia ingresado es Viernes");
                break;
            case "6":
                Console.WriteLine("El dia ingresado es Sabado");
                break;
            case "7":
                Console.WriteLine("El dia ingresado es Domingo");
                break;
            default:
                Console.WriteLine("Seleccione un dia valido");
                break;
        }


        Console.ReadKey();
    }
}
