﻿class program
{
    static void Main(string[] args)
    {
        MostrarMenuPrincipal();
    }
    static void MostrarMenuPrincipal()
    {
        while (true) 
        {
            Console.WriteLine("Revision de fallas en maquinaria");
            Console.WriteLine("Menu de opciones");
            Console.WriteLine("1. Revision de Parametros");
            Console.WriteLine("2. Manual de Usuario");
            Console.WriteLine("3. Creditos");
            Console.WriteLine("4. Salir");

           string SeleccionMenu;
            Console.WriteLine("Seleccione una Opcion");
            SeleccionMenu = Console.ReadLine();
            switch (SeleccionMenu)
            {
                case "1":

                    MenuProcesoPrincipal();

                break;

                case "2":

                    ManualdeUsuario();                

                break;

                case "3":

                    MenuCreditos();

                break;

                case "4":

                    Environment.Exit(0);

                    break;

                default:
                Console.WriteLine("Seleccione una opcion valida");
                
                break;
            }
        }

    }

    static void MenuProcesoPrincipal()
    {

        while (true)
        {
            Console.Clear();
            Console.WriteLine("Revision de Parametros");
            Console.WriteLine("Menu de opciones");
            Console.WriteLine("1. Maquina de Soplado");
            Console.WriteLine("2. Maquina de llenado de botellas");
            Console.WriteLine("3. Maquina de Etiquetas");
            Console.WriteLine("4. Maquina de Envoltura");
            Console.WriteLine("5. Regresar al Menu Principal");
            Console.WriteLine("Seleccione la maquina que desea revisar");

            string maquinaria;
            maquinaria = Console.ReadLine();
            switch (maquinaria)
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine("Maquina de Soplado");;
                    Console.WriteLine();
                    Console.WriteLine("Regresar al Menu Anterior (si/no)");
                    string opcion;
                    opcion = Console.ReadLine();
                    if(opcion=="si")
                    {
                       Console.Clear();
                       MenuProcesoPrincipal();
                    }
                else if(opcion=="no")
                {
                    Console.WriteLine("Regresar al Menu Principal (si/no)");
                    string opcion1;
                    opcion1 = Console.ReadLine();
                    if (opcion1 == "si")
                    {
                        Console.Clear();
                        MenuProcesoPrincipal();
                    }
                    else if (opcion1 == "no")
                    {
                        Environment.Exit(0);
                    }
                }
                break;

            case "2":
                Console.Clear();
                Console.WriteLine("Maquina de llenado de botellas");
                Console.WriteLine();
                Console.WriteLine("Regresar al Menu anterior (si/no)");
                string opcion2;
                opcion2 = Console.ReadLine();
                if (opcion2 == "si")
                {
                    Console.Clear();
                    MenuProcesoPrincipal();
                }
                else if (opcion2 == "no")
                {
                    Console.WriteLine("Regresar al Menu Principal (si/no)");
                    string opcion6;
                    opcion6 = Console.ReadLine();
                    if (opcion6 == "si")
                    {
                        Console.Clear();
                        MostrarMenuPrincipal();
                    }
                    else if (opcion6 == "no")
                    {
                        Environment.Exit(0);
                    }
                }
                break;

            case "3":
                Console.Clear();
                Console.WriteLine("Maquina de Etiquetas");
                Console.WriteLine();
                Console.WriteLine("Regresar al Menu anterior (si/no)");
                string opcion3;
                opcion3 = Console.ReadLine();
                if (opcion3 == "si")
                {
                    Console.Clear();
                    MenuProcesoPrincipal();
                }
                else if (opcion3 == "no")
                {
                    Console.WriteLine("Regresar al Menu Principal (si/no)");
                    string opcion7;
                    opcion7 = Console.ReadLine();
                    if (opcion7 == "si")
                    {
                        Console.Clear();
                        MostrarMenuPrincipal();
                    }
                    else if (opcion7 == "no")
                    {
                        Environment.Exit(0);
                    }
                }
                break;

            case "4":
                Console.Clear();
                Console.WriteLine("Maquina de Envoltura");
                Console.WriteLine();
                Console.WriteLine("Regresar al Menu anterior (si/no)");
                string opcion4;
                opcion4 = Console.ReadLine();
                if (opcion4 == "si")
                {
                    Console.Clear();
                    MenuProcesoPrincipal();
                }
                else if (opcion4 == "no")
                {
                    Console.WriteLine("Regresar al Menu Principal (si/no)");
                    string opcion8;
                    opcion8 = Console.ReadLine();
                    if (opcion8 == "si")
                    {
                        Console.Clear();
                        MostrarMenuPrincipal();
                    }
                    else if (opcion8 == "no")
                    {
                        Environment.Exit(0);
                    }
                }
                break;

            case "5":
                Console.Clear();
                MostrarMenuPrincipal();
                break;

            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
        }

        }
    }

    static void ManualdeUsuario()
    {
        Console.Clear();
        Console.WriteLine("Manual de Usuario");
        Console.WriteLine();
        Console.WriteLine("I. Opciones del Programa:");
        Console.WriteLine("1. Proceso Principal");
        Console.WriteLine("2. Manual de Usuario");
        Console.WriteLine("3. Creditos");
        Console.WriteLine("4. Salir");
        Console.WriteLine();

        Console.WriteLine("II. Pasos para Mostrar la Solución de Problemática:");
        Console.WriteLine("1. Seleccione la opción 'Proceso Principal' en el menú principal.");
        Console.WriteLine("2. Elija la máquina de interés o regrese al menú principal si es necesario.");
        Console.WriteLine("3. Revise los niveles de temperatura y energía para la máquina.");
        Console.WriteLine("4. Decida si desea regresar al menú anterior o al menú principal.");
        Console.WriteLine();

        Console.WriteLine("III. Propósito del Programa:");
        Console.WriteLine("El programa 'Revision de fallas en maquinaria' tiene como objetivo proporcionar");
        Console.WriteLine("una herramienta para monitorear y diagnosticar el estado de diversas máquinas en");
        Console.WriteLine("una embotelladora de agua. Permite a los usuarios revisar niveles críticos");
        Console.WriteLine("de presión, temperatura y energía en diferentes máquinas, así como acceder a información");
        Console.WriteLine("adicional en el manual de usuario y conocer los créditos del proyecto.");
        Console.WriteLine();

        Console.WriteLine("Regresar al Menu Principal (si/no)");
        string opcion5 = Console.ReadLine();
        if (opcion5 == "si")
        {
            Console.Clear();
            MostrarMenuPrincipal();
        }
        else if (opcion5 == "no")
        {
            Environment.Exit(0);
        }
    }

    static void MenuCreditos()
    {
        Console.Clear();
        Console.WriteLine("Creditos");
        Console.WriteLine();
        Console.WriteLine("Nombre del Proyecto");
        Console.WriteLine("-Revision de Fallas en Maquinaria-");
        Console.WriteLine();
        Console.WriteLine("Fecha de Creacion ");
        Console.WriteLine("--/--/----");
        Console.WriteLine();
        Console.WriteLine("Integrantes");
        Console.WriteLine("Juan Garrido Ingeniería Mecánica Industrial 1126223");
        Console.WriteLine("Santiago Escobar Ingeniería Mecánica 1060223");
        Console.WriteLine();
        Console.WriteLine("Regresar al Menu Principal (si/no)");
        string opcion5;
        opcion5 = Console.ReadLine();
        if (opcion5 == "si")
        {
            Console.Clear();
            MostrarMenuPrincipal();
        }
        else if (opcion5 == "no")
        {
            Environment.Exit(0);
        }

    }
    
}