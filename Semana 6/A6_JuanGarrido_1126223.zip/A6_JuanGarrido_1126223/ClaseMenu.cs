﻿class ClaseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa, Prevencion de fallos en maquinaria");
        Console.WriteLine("Seleccione el tipo de maquina");
        Console.WriteLine();
        Console.WriteLine("Menu Principal");
        Console.WriteLine("1. Maquina de soplado");
        Console.WriteLine("2. Maquina de llenado de botellas");
        Console.WriteLine("3. Maquina de etiquetas");
        Console.WriteLine("4. Maquina de envoltura");
        Console.WriteLine();
        string SeleccionMenu;
        SeleccionMenu = Console.ReadLine();

        switch (SeleccionMenu)
        {
            case "1":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + ". Maquina de soplado");
                break;
            case "2":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + ". Maquina de llenado de botellas");
                break;
            case "3":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + ". Maquina de etiquetas");
                break;
            case "4":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + ". Maquina de etiquetas");
                break;
         
            default:
                Console.WriteLine("Seleccione una opcion valida");
                break;
        }


        Console.ReadKey();
    }
}
