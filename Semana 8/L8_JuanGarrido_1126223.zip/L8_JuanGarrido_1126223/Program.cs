﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Tomando la ecuacion");
        Console.WriteLine("Vf = Vo + at");
        Console.WriteLine("Ingrese 3 de las 4 variables para calcular la cuarta:");

        double vf = 0, v0 = 0, a = 0, t = 0;

       
        Console.Write("Ingrese Velocidad Final (m/s): ");
        if (double.TryParse(Console.ReadLine(), out vf))
        {
            Console.Write("Ingrese Velocidad Inicial (m/s): ");
            if (double.TryParse(Console.ReadLine(), out v0))
            {
                Console.Write("Ingrese Aceleración (m/s^2): ");
                if (double.TryParse(Console.ReadLine(), out a))
                {
                    Console.Write("Ingrese Tiempo (s): ");
                    if (double.TryParse(Console.ReadLine(), out t))
                    {
                        Console.WriteLine("Error: Debes ingresar solo 3 de las 4 variables.");
                    }
                    else
                    {
                        t = (vf - v0) / a;
                        Console.WriteLine("El tiempo es: " + t + " segundos");
                    }
                }
                else
                {
                    a = (vf - v0) / t;
                    Console.WriteLine("La aceleración es: "+ a + " m/s^2");
                }
            }
            else
            {
                 v0 = vf - (a * t);
                Console.WriteLine("La velocidad inicial es: " + v0 + " m/s");
            }
        }
        else
        {
            vf = v0 + (a * t);
            Console.WriteLine("La velocidad final es: " + vf + " m/s");
        }
    }
}
